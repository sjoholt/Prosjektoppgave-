package no.ntnu.projectserver;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * @author Team Tungrocken
 */
@ApplicationPath("services")

public class RestConfiguration extends Application {
}
